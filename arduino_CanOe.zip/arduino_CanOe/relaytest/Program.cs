﻿using arduino_CanOe;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;

namespace relaytest
{
    class Program
    {
        static void Main(string[] args)
        {
            IoApi.getExistingSerialPortNames();
            IoApi io = new IoApi("COM3");
            var t = io.WaitUntillReady(90000);
            Console.WriteLine("set input output");
            Console.WriteLine("sets pin A3 to input:" + io.PinMode("A03", IoApi.mode.input).ToString());
            Console.WriteLine( "sets pin 13 to output:" + io.PinMode("12", IoApi.mode.output).ToString() );
            Console.WriteLine("sets pin 13 to output:" + io.PinMode("02", IoApi.mode.output).ToString());
            Console.WriteLine("sets pin 13 to output:" + io.PinMode("03", IoApi.mode.input).ToString());

            Console.WriteLine("sets pin 2 to high:" + io.DigitalWrite(2, true).ToString());
            Console.WriteLine("read pin3 should be 0 ");
            Console.WriteLine("digital read on pin 3:" + io.DigitalRead(3) );
            Console.WriteLine("Anlalog read on pin A3:" + io.AnalogRead(3));
            Thread.Sleep(1000);
            Console.WriteLine("set 13 to hig");
            Console.WriteLine("sets pin 13 to high:" + io.DigitalWrite(12,true).ToString());
            Thread.Sleep(100);
            Console.WriteLine("read pin 3 should be hihg");
            Console.WriteLine("digital read on pin 3:" + io.DigitalRead(3));
            double A3A = double.Parse(io.AnalogRead(3)) * (5.000/1023.0);
            Console.WriteLine("Anlalog read on pin A3:" + A3A);
            Thread.Sleep(1000);
            Console.WriteLine("sets pin 13 to low:" + io.DigitalWrite(12, false).ToString());
            Thread.Sleep(3000);
            Console.WriteLine("read pin3 should be 0 ");
            double A3 = double.Parse(io.AnalogRead(3)) * (5.000 / 1023.0);
            Console.WriteLine("Anlalog read on pin A3:" + A3);
            Console.WriteLine("digital read on pin 3:" + io.DigitalRead(3));
            

            var s = "";

        }
    }
}
