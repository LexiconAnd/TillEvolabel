﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.IO.Ports;

namespace arduino_CanOe
{
    public class IoApi
    {
        private SerialPort sp;
        public enum mode { input,output};
        public IoApi(string port)
        {
            sp = new SerialPort(port, 115200, Parity.None,8,StopBits.One);
            sp.ReadTimeout = 900;
            sp.Open();
            sp.DtrEnable = true;
        }

        ~IoApi()
        {
            sp.Close();
        }

        public static void getExistingSerialPortNames()
        {
            foreach ( string item in SerialPort.GetPortNames())
            {
                Console.WriteLine(item);
            }
        }

        public bool WaitUntillReady(int timeout)
        {
            string msg = "!00000000.";
            int count = 0;
            int sleeptime = 2000;
            int numberoffTraies = timeout / sleeptime;
                     
            sp.Write(msg);
            //Console.WriteLine(msg);
            Thread.Sleep(sleeptime);
            while (sp.BytesToRead == 0 && count != numberoffTraies)
            {                               
                sp.Write(msg);
                Thread.Sleep(sleeptime);                
                count++;
            }
            string[] respons = sp.ReadExisting().Split(new string[] { "\r\n" }, StringSplitOptions.None);
            if( count == numberoffTraies)
            {
                return false;
            }
            return true;
        }

        public bool PinMode(string pin, mode pinmode)
        {
            string msg = "!00" + pin + ((int)pinmode).ToString("00") + ".";
            sp.Write(msg);
            //Console.WriteLine(msg);
            var a2 = sp.BytesToWrite;
            Thread.Sleep(8);
            
            string[] respons = sp.ReadExisting().Split(new string[] { "\r\n" },StringSplitOptions.None);
            if ( respons[1] == "sm")
            {
                return true;
            }
            return false;
        }

        public bool DigitalWrite(int pin, bool high)
        {
            string msg = "!01" + pin.ToString("00");
            msg += (high) ? "001" : "000";
            msg += ".";
            sp.Write( msg );
            //Console.WriteLine(msg);
            Thread.Sleep(8);
            string[] respons = sp.ReadExisting().Split(new string[] { "\r\n" }, StringSplitOptions.None);
            if (respons[1] == "dw")
            {
                return true;
            }
            return false;
        }

        public string DigitalRead(int pin)
        {
            string msg = "!02" + pin.ToString("00") + "00" + ".";
            sp.Write(msg);
            //Console.WriteLine(msg);
            Thread.Sleep(8);
            string[] respons = sp.ReadExisting().Split(new string[] { "\r\n" }, StringSplitOptions.None);

            return respons[2].Substring(4);
        }

        public void AnalogWrite(int pin, int val)
        {
            if ( val > 255)
            {
                val = 255;
            }
            string msg = "!03" + pin.ToString("00") + val.ToString("00") + ".";
            sp.Write(msg);
            Console.WriteLine(msg);
            Thread.Sleep(8);
            string[] respons = sp.ReadExisting().Split(new string[] { "\r\n" }, StringSplitOptions.None);
        }

        public string AnalogRead(int pin)
        {
            string msg = "!04" + pin.ToString("00") + "00" + ".";
            sp.Write(msg);
           // Console.WriteLine(msg);
            Thread.Sleep(8);
            string[] respons = sp.ReadExisting().Split(new string[] { "\r\n" }, StringSplitOptions.None);
            return respons[2].Substring(4);
        }       

    }
}
