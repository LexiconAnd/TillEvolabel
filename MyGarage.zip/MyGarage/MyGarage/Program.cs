﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MyGarage
{

     

    class Program
    {
        class Vehicle
        {
            public string licencePlate;
            public int size;
            public Vehicle(string lp) { licencePlate = lp; }
        }
        class Car : Vehicle
        {
            public Car(string lp) : base(lp) { size = 2; }
        }
        class Motorcycle : Vehicle
        {
            public Motorcycle(string lp) : base(lp) { size = 1; }
        }
        class Garage
        {
            static int MAX = 4;    // max number slots= 100
            public ParkingSpace[] parkingSlot;
            public Garage()
            {
                parkingSlot = new ParkingSpace[MAX];
                for (int i = 0; i < parkingSlot.Count(); i++)
                {
                    ParkingSpace ps = new ParkingSpace();
                    parkingSlot[i] = ps;
                }
            }
            public void AddVehicle(int slotNr, Vehicle v)
            {
                parkingSlot[slotNr].AddVehicle(v);
            }
            public void AddVehicle(Vehicle v)
            {
                // find some empty space
                int vehicleSize = v.size;

                ParkingSpace ps;
                bool added = false; // vehicle not added yet
                for (int i = 0; i < parkingSlot.Count(); i++)
                {
                    ps = parkingSlot[i];
                    int capacity = ps.CurrentCapacity();
                    if (capacity >= vehicleSize)
                    {
                        ps.AddVehicle(v);
                        added = true;
                        break;
                    }
                }
                if (!added) Console.WriteLine("------------------------ Sorry. No empty space.");
            }
            public bool FindVehicle(string lplate)
            {
                ParkingSpace ps;
                bool found = false;
                for (int i = 0; i < parkingSlot.Count(); i++)
                {
                    ps = parkingSlot[i];
                    found = ps.FindVehicle(lplate);
                    if (found) break;
                }
                return found;
            }
            public bool RemoveVehicle(string lplate)
            {   // do it again :(
                bool removed = false;
                ParkingSpace ps;
                for (int i = 0; i < parkingSlot.Count(); i++)
                {
                    ps = parkingSlot[i];
                    removed = ps.RemoveVehicle(lplate);
                    if (removed)
                    {
                        Console.WriteLine("Vehicle " + lplate + " successfully removed.");
                        break;
                    }
                }
                return removed;
            }
            public void PrintSlotInfo(int slotNr)
            {
                parkingSlot[slotNr].PrintParkingSpaceInfo();
            }
            public void PrintGarageInfo()
            {
                Console.WriteLine();
                Console.WriteLine("-------Garage info -------------------------");

                Console.WriteLine("Slot nr |Capacity  |Vehicles");
                for (int i = 0; i < parkingSlot.Count(); i++)
                {
                    //Console.WriteLine("-------Slot " + i + "----------");
                    Console.Write(i + "       |");
                    parkingSlot[i].PrintParkingSpaceInfo();
                    Console.WriteLine();
                }

                Console.WriteLine("--------------------------------------------");
                Console.WriteLine();
            }
            public int FreeParkingSlots() { return 0; } // not impelemted yet  
            public int FreeSize() { return 0; } // not implemented yet
        }
        class ParkingSpace
        {
            public int MAXCAPACITY = 2; // assume that each slot has same MAXCAPACITY            public int capacity;
            public List<Vehicle> list;  // list of vehicles
            public int capacity;

            public ParkingSpace()
            {
                list = new List<Vehicle>(); //list.Clear();
                capacity = MAXCAPACITY;
            }
            public int MaxCapacity() { return MAXCAPACITY; }
            public void PrintParkingSpaceInfo()
            {
                // Console.WriteLine("Pos RegNr  VehicleSize");
                int curCapacity = CurrentCapacity();
                Console.Write(curCapacity + "         |");
                for (int i = 0; i < list.Count(); i++)
                {
                    Vehicle v = list.ElementAt(i);
                    Console.Write(v.licencePlate + " {0} | ", v.size);
                }
            }
            public void AddVehicle(Vehicle veh)
            {
                list.Add(veh);
            }
            public bool FindVehicle(string s)
            {
                bool found = false;
                Vehicle v;
                for (int i = 0; i < list.Count(); i++)
                {
                    v = list.ElementAt(i);
                    if (v.licencePlate == s)
                    {
                        found = true;
                        break;
                    }
                }
                return found;
            }
            public bool RemoveVehicle(string s)
            {
                bool removed = false;
                for (int i = 0; i < list.Count(); i++)
                {
                    if (list.ElementAt(i).licencePlate == s)
                    {
                        list.RemoveAt(i);
                        removed = true;
                        break;
                    }
                }
                return removed;
            }
            public int CurrentCapacity()
            {
                int sum = 0;
                for (int i = 0; i < list.Count(); i++)
                {
                    sum = sum + list.ElementAt(i).size;
                }
                return (MaxCapacity() - sum);
            }
        }
        static void Main(string[] args)
        {
            bool ready = false;
            string licPlate;
            Vehicle v;
            Garage g = new Garage();
            while (!ready)
            {
                Console.Write("c-car, m-motorcycle, f-find, r-remove, q-quit :");
                string answer = Console.ReadLine();
                switch (answer)
                {
                    case "q":
                        ready = true;
                        break;
                    case "f":
                        Console.Write("Licence plate: ");
                        licPlate = Console.ReadLine();
                        g.FindVehicle(licPlate);
                        break;
                    case "r":
                        Console.Write("Licence plate: ");
                        licPlate = Console.ReadLine().TrimStart();
                        g.RemoveVehicle(licPlate);
                        break;
                    case "c":
                        Console.Write("Licence plate: ");
                        licPlate = Console.ReadLine();
                        v = new Car(licPlate);
                        g.AddVehicle(v);
                        break;
                    case "m":
                        Console.Write("Licence plate: ");
                        licPlate = Console.ReadLine();
                        v = new Motorcycle(licPlate);
                        g.AddVehicle(v);
                        break;

                    default:
                        break;
                }
                g.PrintGarageInfo();
            }
            Console.WriteLine("Good Bye!");
            Console.ReadKey();
        }
    }
}
