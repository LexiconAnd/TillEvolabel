﻿using System;
using System.Collections.Generic;
using System.Linq;

namespace SimpleGarage
{
    // in this SimpleGarage you can only ADD vehicles, no removal :)

    public class Vehicle
    {
    }
    public class Garage
    {
        private int MAX = 5;  // MAX=100;
        public ParkingSpace[] parkingSlot;
        public Garage()
        {
            parkingSlot = new ParkingSpace[MAX];
            for (int i = 0; i < parkingSlot.Count(); i++)
            {
                parkingSlot[i] = new ParkingSpace();
            }
        }
        public void AddVehicle(int slotNr) 
        {
             parkingSlot[slotNr].AddVehicle();
        }
          
        public void PrintInfo()
        {
            Console.WriteLine("-------Garage Info --------");
            for (int i = 0; i < parkingSlot.Count(); i++)
            {
                Console.Write(i + ":");
                Console.Write(parkingSlot[i].Info());
                Console.WriteLine(" vehicles.");
            }
            Console.WriteLine("-------Garage End  --------");

        }
    }
    public class ParkingSpace
    {
        public List<Vehicle> list;
        public ParkingSpace()
        {
            list = new List<Vehicle>();
        }
        public void AddVehicle()
        {
                list.Add(new Vehicle());
        }
        public int Info()
        {
            return list.Count();  // returns how many vehicles at this space
        }
          
    }

    class Program
    {
        static void Main(string[] args)
        {
            Garage g = new Garage();
            // Main menu loop
            bool ready = false;
            int spotNr;

            while (!ready)
            {
                Console.Write("a-add, q-quit: ");
                string answer = Console.ReadLine();
                switch (answer)
                {
                    case "q":
                        ready = true;
                        break;
                    case "a":
                        Console.Write("Add Vehicle to spotNr (<5):");
                        spotNr = Int32.Parse(Console.ReadLine());
                        g.AddVehicle(spotNr);
                        break;
                    default:
                        break;
                }
                g.PrintInfo();

            }
        }
    }
}



 