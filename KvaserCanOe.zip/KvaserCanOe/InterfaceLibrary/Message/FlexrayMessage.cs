﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AutoTestNow
{
    public class FlexrayMessage
    {
        public int id;

        public override string ToString()
        {
            return base.ToString();
        }
    }
}
