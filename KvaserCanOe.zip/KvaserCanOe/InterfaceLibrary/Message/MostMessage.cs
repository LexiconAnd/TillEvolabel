﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AutoTestNow
{
    public class MostMessage
    {
        int Source=0;
        int Sestanation=0;
        bool IsAMS=false;
        int Fid =0;
        int Fblock=0;
        int InstanceId=0;
        byte[] data = new byte[255];

        public override string ToString()
        {
            return base.ToString();
        }
    }
}
