﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AutoTestNow
{
    public class LinMessage
    {
        public int id;
        public byte[] data = new byte[8] { 0, 0, 0, 0, 0, 0, 0, 0 };
        public int dlc;
        public int flag;
        public long time;

        public override string ToString()
        {
            return base.ToString();
        }
    }
}
