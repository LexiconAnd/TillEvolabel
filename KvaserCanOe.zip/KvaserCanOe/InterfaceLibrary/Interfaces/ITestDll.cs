﻿using System.Collections.Generic;

namespace AutoTestNow
{
    public interface ITestDll
    {
        // This will be pointers to the program and be populated before execution by main program
        dynamic Db { get; set; }
        IVerification Verify { get; set; }
        IBusses Buss { get; set; }
        ITools Tools { get; set; }
        IExtra Extra { get; set; }
        Dictionary<string, string> Parameters { get; set; }
        /// <summary>
        /// In this variable will all plugging be accessible
        /// </summary>
        List<PluginClass> Plugins { get; set; }

        void Requirements(); // in this function you can set up if the file is needed to run the test.
        void Configuration();  // this to function is where you set up configuration on the test
        /// <summary>
        /// This is the function that will be called by the main program and it returns data to main program.
        /// </summary>
        /// <returns></returns>
        bool TestStart();
    }
}
