﻿
namespace AutoTestNow
{
    public interface IOscilloscope
    {
        HWType Info(); // returns details about the tool
        string Costumed(string request);
        void Buzzer();
        bool CheckForErrors();// will return a list off all set errors in the Oscilloscope by asking this Device Dependent or device specific error Register (DDR ),E vent Status Register (ESR),Execution error Register (EXR )
        bool AutoConfig(); // runs AUTO_CALIBRATE and AUTO_SETUP
        System.Drawing.Bitmap SCREEN_DUMP(); // SCDP
        double Volt();
        double Amplitude();
        double Frequency();
        double Period();
        double Maximum();
        double Minimum();
        double Mean();
        double FallTime();
        double RiseTime();
        double DutyCycle();
        bool   GreaterThan(double value);
        bool   LessThan(double value);
        int CountProbs();
        /*
        area
        base                                            
        */
    }
}