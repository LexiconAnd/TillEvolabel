﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace AutoTestNow
{
    public interface ITools
    {
        List<IOscilloscope> Oscilloscope { set; get; }
        List<IPowerSupply> PowerSupply { set; get; }
        List<IRelay> Relay { set; get; }

        bool HasOscilloscope();
        bool HasPowerSupply();
        bool HasRealy();
    }
}
