﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace AutoTestNow
{
    public interface IPowerSupply
    {
        string HwVender { get; set; }
        String HwModelName { get; set; }
        string HwType { get; set; }
        string HwConnectionType { get; set; }
        Double Volt(Double volt = 0);
        Double Amplitude(Double amp = 0);
        string Costumed(string request);
    }
}
