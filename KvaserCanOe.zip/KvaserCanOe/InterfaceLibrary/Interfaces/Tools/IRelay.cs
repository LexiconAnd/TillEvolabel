﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace AutoTestNow
{
    public interface IRelay
    {
        HWType Info(); // returns details about the tool
        string Costumed(string request);
        bool ActivateRelay(int relay);
        bool ActivateRelay(int[] relays);
        bool DeactivateRelay(int relay);
        bool StatusRelay(int relay);
        int Count();

    }
}
