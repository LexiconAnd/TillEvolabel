﻿namespace AutoTestNow
{
    public class HWType
    {
        public string brand { set; get; }
        public string type { set; get; }
    }
}