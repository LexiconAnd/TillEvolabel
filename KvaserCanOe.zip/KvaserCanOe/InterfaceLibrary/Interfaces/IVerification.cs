﻿
namespace AutoTestNow
{
    public interface IVerification
    {
        /// <summary>
        /// Creates a test Suite in the database
        /// </summary>
        /// <param name="Name">the name off the test suite</param>
        /// <param name="Description">Description off what the test suite will do </param>
        /// <param name="Requirement">the requirement tag that the test suite will for fill</param>
        /// <param name="AffectedArea">and description off what area that the suite will affect.</param>
        void TestSuite(string Name, string Description = "", string Requirement = "", string AffectedArea = "");
        /// <summary>
        /// Creates a test case in the database
        /// </summary>
        /// <param name="Name">the name off the test case</param>
        /// <param name="Description">Description off what the test case will do </param>
        /// <param name="Requirement">the requirement tag that the test case will for fill</param>
        /// <param name="AffectedArea">and description off what area that the test case will affect.</param>
        void TestCase(string Name, string Description = "", string Requirement = "", string AffectedArea = "");
        /// <summary>
        /// Adds a test step to the database with test data 
        /// </summary>
        /// <param name="Name">the name off the test.</param>
        /// <param name="TestResult">Test result OK,NOK,ABORTED</param>
        /// <param name="Comment">descriptive text off what has gone wrong</param>
        /// <param name="ExecutionTime">how long time the test has executed </param>
        /// <param name="Description">Description off what the test is suppose to do.</param>
        /// <param name="Data">Holds extra data for example picture,log or other data that can help on verification</param>
        /// <returns></returns>
        int TestStep(string Name, string TestResult = "OK", string Comment = "", double ExecutionTime = 0, string Description = "", byte[] data=null);
        /// <summary>
        /// Adds a test step to the database with test data 
        /// </summary>
        /// <param name="Name">the name off the test.</param>
        /// <param name="result">this can be a function that will evaluate over time or a bool that sets the value</param>
        /// <param name="timeout">how long before a result has to be received</param>
        /// <returns>returns a pointer to where in the database the test step is stored that can be used in AddComment</returns>        
        int OK(string Name, bool result, int timeout );
        int OK(string Name, System.Func<bool> Result, int timeout);
        /// <summary>
        /// Adds a comment to a test step item in the database with the test step Id as an identifier
        /// </summary>
        /// <param name="id">the database Id field that is returned from TestSep or OK</param>
        /// <param name="Comment">Takes the comment that should be added in the database</param>
        /// <param name="Description">An description off what the test is suppose to do</param>
        /// <param name="Data">Holds extra data for example picture,log or other data that can help on verification</param>
        void AddComment(int id, string Comment, string Description="", byte[] Data =null);
          
    }
}