﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace AutoTestNow
{
    public interface IExtra
    {
        //List<>
        //bool Has??();
    }
}
