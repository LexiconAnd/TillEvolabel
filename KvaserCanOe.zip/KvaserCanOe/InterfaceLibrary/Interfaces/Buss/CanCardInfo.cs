﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace AutoTestNow.Interfaces.Buss
{
    public class CanCardInfo
    {
        public Vendor vendor;
        public string alias;
        public int chanHandle;
        public int channel;

        public int bitrate = 0;
        public int tseg1 = 0;
        public int tseg2 = 0;
        public int sjw = 0;
        public int noSamp = 0;
        public int synkmode = 0;

        public string db = "";

        public void parseVendor(string _vendor)
        {
            switch(_vendor.ToLower()){
                case "kvaser":
                    vendor = Vendor.Kvaser;
                    break;
                case "vector":
                    vendor = Vendor.Vector;
                    break;
                case "logfile":
                    vendor = Vendor.Logfile;
                    break;
                default:
                    vendor = Vendor.None;
                    break;
            }
        }
        public enum Vendor
        {
            None,
            Kvaser,
            Vector,
            Logfile
        };
    }
}
