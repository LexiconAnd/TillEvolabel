﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AutoTestNow.Classes.Buss
{
    public abstract class AbstractCanCard
    {
        public AutoTestNow.Interfaces.Buss.CanCardInfo info = new AutoTestNow.Interfaces.Buss.CanCardInfo();
        public Dictionary<string, string> Parameters;
        public AutoTestNow.Interfaces.IDatabase CanDb;
        public volatile bool _cancel = false;

        public void Cancel()
        {
            _cancel = true;
        }

        abstract public void Recive(CanMessage frame);
        abstract public void Send(CanMessage frame);
        abstract public void Dowork();
    }
}
