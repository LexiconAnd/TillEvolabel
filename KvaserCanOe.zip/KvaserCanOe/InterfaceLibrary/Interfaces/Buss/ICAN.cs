﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace AutoTestNow
{
    public delegate void ReciveFrameEventHandlerCan(CanMessage frame);
    public delegate void SendFrameEventHandlerCan(CanMessage frame);
    public interface ICAN
    {
        event ReciveFrameEventHandlerCan ReciveFrame;
        event SendFrameEventHandlerCan SentFrame;        
       
        bool Send(CanMessage msg);
        
        int Count();

        AutoTestNow.Interfaces.IDatabase CanDB(string alias);
   //     T Signal<T>(String name); // Template method for different return variables http://stackoverflow.com/questions/2144495/creating-a-generic-method-in-c-sharp

    }
}
