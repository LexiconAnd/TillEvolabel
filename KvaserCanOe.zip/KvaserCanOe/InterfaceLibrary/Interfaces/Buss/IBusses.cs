﻿using System.Collections.Generic;

namespace AutoTestNow

{
    public interface IBusses
    {
        /// <summary>
        /// This variable holds all CAN buss interfaces and functions. 
        /// </summary>
        ICAN CAN { get; set; }      
        /// <summary>
        /// This variable holds all LIN buss interfaces and functions. 
        /// </summary>
        List<ILIN> LIN { get; set; }
        /// <summary>
        /// This variable holds all MOST buss interfaces and functions. 
        /// </summary>
        List<IMOST> MOST { get; set; }
        /// <summary>
        /// This variable holds all FLEXRAY buss interfaces and functions. 
        /// </summary>
        List<IFLEXRAY> FLEXRAY { get; set; }
        //List<II2C> I2C { get; set; }
        //List<IBT> BT { get; set; }
        //List<IEthernet> Ethernet { get; set; }
        //List<IJ1587> J1587 { get; set; } // Diagnose protocol truck
        //List<I14229> 14229 {get; set;} // Diagnose protocol car

        /// <summary>
        /// Checks if there is any CAN buss interfaces available and allocated in main program
        /// </summary>
        /// <returns>true if Main program has one or more CAN interfaces</returns>
        bool HasCAN();
        /// <summary>
        /// Checks if there is any LIN buss interfaces available and allocated in main program
        /// </summary>
        /// <returns>true if Main program has one or more LIN interfaces</returns>
        bool HasLIN();
        /// <summary>
        /// Checks if there is any MOST buss interfaces available and allocated in main program
        /// </summary>
        /// <returns>true if Main program has one or more MOST interfaces</returns>
        bool HasMOST();
        /// <summary>
        /// Checks if there is any FLEXRAY buss interfaces available and allocated in main program
        /// </summary>
        /// <returns>true if Main program has one or more FLEXRAY interfaces</returns>
        bool HasFLEXRAY();
    }
}