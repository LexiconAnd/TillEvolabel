﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace AutoTestNow
{
    public delegate void ReciveFrameEventHandlerLin(LinMessage frame);
    public delegate void SendFrameEventHandlerLin(LinMessage frame);
    public interface ILIN
    {
        event ReciveFrameEventHandlerLin ReciveFrame;
        event SendFrameEventHandlerLin SentFrame;

        bool Send(CanMessage msg);

        int Count();
        //LinMessage Frame(int id);
        //LinMessage Frame(LinMessage msg);
        //T Signal<T>(String name); // Template method for different return variables http://stackoverflow.com/questions/2144495/creating-a-generic-method-in-c-sharp

    }
}
