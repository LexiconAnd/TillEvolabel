﻿namespace AutoTestNow
{
    public interface IFLEXRAY
    {
        FlexrayMessage Frame(int id);
        FlexrayMessage Frame(FlexrayMessage msg);
        T Signal<T>(string name); // Template method for different return variables http://stackoverflow.com/questions/2144495/creating-a-generic-method-in-c-sharp

    }
}