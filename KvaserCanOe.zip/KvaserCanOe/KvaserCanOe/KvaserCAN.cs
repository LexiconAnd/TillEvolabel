﻿using canlibCLSNET;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using AutoTestNow;
using AutoTestNow.Classes;
using AutoTestNow.Interfaces;
using AutoTestNow.Interfaces.Buss;
using AutoTestNow.Classes.Buss;

namespace KvaserCanOe
{
    class CanCardKvaserThread : AbstractCanCard
    {
        // public volatile bool _cancel = false; // is in abstract class
        private KvaserCan CanOe;
        public CanCardKvaserThread()
        {
            CanOe = new KvaserCan();
            Canlib.canInitializeLibrary();            
            object name;
             Canlib.canStatus Status = Canlib.canGetChannelData(0, Canlib.canCHANNELDATA_DEVNAME_ASCII, out name);
            if (Status == Canlib.canStatus.canOK)
            {
                Console.WriteLine(name.ToString());  // debug test code for device nick name
            }            
        }

        override public void Recive(CanMessage frame)
        {
            CanOe.SendFrame(frame);
        }

        override public void Send(CanMessage frame)
        {
            Canlib.canStatus status;
            frame.flags = (frame.extended) ? Canlib.canMSG_EXT : Canlib.canMSG_STD;
            frame.sFlags = String.Format("{0}{1}{2}{3}{4}",
                                            ((frame.flags & Canlib.canMSGERR_OVERRUN) > 0) ? "O" : " ",
                                            ((frame.flags & Canlib.canMSG_EXT) > 0) ? "X" : "S",
                                            ((frame.flags & Canlib.canMSG_RTR) > 0) ? "R" : "T",
                                            ((frame.flags & Canlib.canMSG_TXACK) > 0) ? "A" : " ",
                                            ((frame.flags & Canlib.canMSG_WAKEUP) > 0) ? "W" : " ");
            status = Canlib.canWrite(info.channel, frame.id, frame.data, frame.dlc, frame.flags);
            //status = Canlib.canWriteSync(info.channel, 500);
            //status = Canlib.canWriteWait(info.channel, frame.id, frame.data, frame.dlc, frame.flags,50); // tries to send the frame for 50 ms
            if (status != Canlib.canStatus.canOK)
            {
                frame.IsErrorFrame = true;
                frame.status = CanMessage.state.failedToSend;
            }
            frame.time = Canlib.canReadTimer(info.chanHandle);
            CanStack.Instance.sent(frame);
        }

        override public void Dowork()
        {
            Console.WriteLine("working Kvaser Thread");
            Object winHandle = new IntPtr(-1);
            // init
            Canlib.canStatus status;

            info.chanHandle = Canlib.canOpenChannel(info.channel, Canlib.canOPEN_ACCEPT_VIRTUAL);
            if ((Canlib.canStatus)this.info.chanHandle != Canlib.canStatus.canOK)
            {
                //CanStack.Instance.Received(new CanMessage(CanMessage.state.canOpenChannel, DateTime.Now.Ticks)); // TODO fixa detta 
            }

            status = Canlib.canSetBusParams(info.chanHandle, ConvertBitRate(info.bitrate), info.tseg1, info.tseg2, info.sjw, info.noSamp, info.synkmode);
            StatusReport(status, CanMessage.state.canSetBusParams);

            status = Canlib.canIoCtl(info.chanHandle, Canlib.canIOCTL_GET_EVENTHANDLE, ref winHandle);
            StatusReport(status, CanMessage.state.canIoCtl);

            object bufLevel = (UInt32)2048;
            status = Canlib.canIoCtl(info.chanHandle, Canlib.canIOCTL_SET_RX_QUEUE_SIZE, ref bufLevel);
            StatusReport(status, CanMessage.state.canIoCtl);

            status = Canlib.canBusOn(info.chanHandle);
            StatusReport(status, CanMessage.state.canBusOn);

            CanLibWaitEvent kvEvent = new CanLibWaitEvent(winHandle);
            WaitHandle[] waitHandles = new WaitHandle[] { kvEvent };
            // looping for data on the buss until thread is canceled

            int id;
            byte[] data = new byte[8];
            int dlc;
            int flags;
            long time;
            String sFlags = "";            
            while (!_cancel) // Main loop
            {
                int index = WaitHandle.WaitAny(waitHandles, 1000, false);
                if (index != 0)
                {
                    if (_cancel)
                    {
                        break; // exit foreach loop if Canselation off thread is requested
                    }
                    status = Canlib.canStatus.canOK;
                    while (status == Canlib.canStatus.canOK)
                    {
                        if (_cancel)
                        {
                            break; // exit foreach loop if Canselation off thread is requested
                        }
                        status = Canlib.canRead(info.chanHandle, out id, data, out dlc, out flags, out time);
                        if (status == Canlib.canStatus.canERR_NOMSG)
                        {
                            break; // continue; // no massages in Que continue
                        }
                        sFlags = String.Format("{0}{1}{2}{3}{4}",
                                            ((flags & Canlib.canMSGERR_OVERRUN) > 0) ? "O" : " ",
                                            ((flags & Canlib.canMSG_EXT) > 0) ? "X" : "S",
                                            ((flags & Canlib.canMSG_RTR) > 0) ? "R" : "T",
                                            ((flags & Canlib.canMSG_TXACK) > 0) ? "A" : " ",
                                            ((flags & Canlib.canMSG_WAKEUP) > 0) ? "W" : " ");
                        if ((flags & Canlib.canMSG_ERROR_FRAME) == Canlib.canMSG_ERROR_FRAME)
                        {
                            Recive(new CanMessage(true, sFlags));
                        }
                        else
                        {
                            Recive(new CanMessage(id, data, dlc, flags, time, sFlags, info.channel));
                        }

                    }

                }

            }
            // Shutting down Connection and thread  
            status = Canlib.canBusOff(info.chanHandle);
            StatusReport(status, CanMessage.state.canBusOff);

            status = Canlib.canClose(info.chanHandle);
            StatusReport(status, CanMessage.state.canClose);
            Console.WriteLine("Kvaser thread is shutdown");
        }

        private void StatusReport(Canlib.canStatus status, CanMessage.state canState)
        {
            if (status != Canlib.canStatus.canOK)
            {
                Console.WriteLine("Error: " + new CanMessage(canState, DateTime.Now.Ticks).ToString());
                // CanStack.Instance.Received(new CanMessage(canState, DateTime.Now.Ticks));
            }
        }

        private int ConvertBitRate(int bitrate)
        {

            switch (bitrate)
            {
                case 1000:
                    return Canlib.canBITRATE_1M;
                case 500:
                    return Canlib.canBITRATE_500K;
                case 250:
                    return Canlib.canBITRATE_250K;
                case 125:
                    return Canlib.canBITRATE_125K;
                case 100:
                    return Canlib.canBITRATE_100K;
                case 83:
                    return Canlib.canBITRATE_83K;
                case 62:
                    return Canlib.canBITRATE_62K;
                case 50:
                    return Canlib.canBITRATE_50K;
                case 10:
                    return Canlib.canBITRATE_10K;
            }
            return 0;
        }

    }
}

