﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
//using Vector.CANoe.Runtime.Internal.DynamicHandlers;
using AutoTestNow.Classes.Buss;
using AutoTestNow;

using Vector.CANoe.Sockets;
using Vector.CANoe.Sockets.Internal;
using Vector.Tools;
using Vector.Tools.Internal;
using Vector.CANoe.Runtime;
using Vector.CANoe.Runtime.Internal;
//using Vector.CANoe.Threading;
//using Vector.CANoe.Diagnostics;
//using Vector.Scripting;
//using Vector.Scripting.UI;
//using Vector.CANoe.TFS;
//using NetworkDB;
//using Vector.CANoe.Runtime.DynamicHandlers;

namespace KvaserCanOe
{
    public class KvaserCan
    {
        private CanCardKvaserThread kvaser = new CanCardKvaserThread();
        public KvaserCan()
        {
            //item.info = card.info;


        }

        public void SendFrame(CanMessage frame) // får frame från Kvaser och skickar den till CanOe
        {
            CANFrame vFrame = new CANFrame(frame.id,frame.dlc);

            vFrame.SetRawData( frame.data) ;
            vFrame.send();

        }

        [OnCANFrame]
        public void onMessage(NetworkDB.Frames.WindowState frame)
        {
            double pos = frame.WindowPosition.Value;
        }

        [OnCANFrame]
        public void onMessage(NetworkDB.Frames.WindowState frame)
        {
            CanMessage kFrame = new CanMessage();
            kFrame.Channel = frame.InternalChannel;
            kFrame.id = frame.InternalID;
            kFrame.dlc = frame.InternalDLC;
            kFrame.time = frame.InternalTimeNS;
            kFrame.data = frame.GetRawData();

            kvaser.Send(kFrame);
        }

        [OnAnyCANFrame]
        public void CANFrameReceived(CANFrame frame)
        {
            CanMessage kFrame = new CanMessage();
            kFrame.Channel = frame.InternalChannel;
            kFrame.id = frame.InternalID;
            kFrame.dlc = frame.InternalDLC;
            kFrame.time = frame.InternalTimeNS;
            kFrame.data = frame.GetRawData();

            kvaser.Send(kFrame);                        
        }


    }

    //[SerializableAttribute]
    //public sealed class OnAnyCANFrameAttribute : FrameHandlerAttribute
    //{
    //    public OnAnyCANFrameAttribute(0x0)
    //    {
                 
    //    }       

    //    [OnAnyCANFrame]
    //    public void CANFrameReceived(CANFrame frame)
    //    {

    //        // send via kvaser can "frame"

    //    }
    //}

}
