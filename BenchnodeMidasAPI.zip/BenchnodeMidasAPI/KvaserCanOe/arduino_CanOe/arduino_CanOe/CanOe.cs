﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Vector.CANoe.Runtime;

namespace arduino_CanOe
{
    class CanOe : Script
    {
        private List<Vector.CANoe.Runtime.DynamicSystemVariable> list = new List<Vector.CANoe.Runtime.DynamicSystemVariable>();
        public void  Script()
        {                   
            //list.Add(  new Vector.CANoe.Runtime.DynamicSystemVariable("Measurement", "DIO1") );
            //list.Add(  new Vector.CANoe.Runtime.DynamicSystemVariable("Measurement", "DIO2") );
            //list.Add(  new Vector.CANoe.Runtime.DynamicSystemVariable("Measurement", "DIO3") );
            //list.Add(  new Vector.CANoe.Runtime.DynamicSystemVariable("Measurement", "DIO4") );
            //list.Add(  new Vector.CANoe.Runtime.DynamicSystemVariable("Measurement", "DIO5") );
            //list.Add(  new Vector.CANoe.Runtime.DynamicSystemVariable("Measurement", "DIO6") );
            //list.Add(  new Vector.CANoe.Runtime.DynamicSystemVariable("Measurement", "DIO7") );
            //list.Add(  new Vector.CANoe.Runtime.DynamicSystemVariable("Measurement", "DIO8") );
            //list.Add(  new Vector.CANoe.Runtime.DynamicSystemVariable("Measurement", "DIO9") );
            //list.Add(  new Vector.CANoe.Runtime.DynamicSystemVariable("Measurement", "DIO10") );

            //list.Add(new Vector.CANoe.Runtime.DynamicSystemVariable("Measurement", "DIO11"));
            //list.Add(new Vector.CANoe.Runtime.DynamicSystemVariable("Measurement", "DIO12"));
            //list.Add(new Vector.CANoe.Runtime.DynamicSystemVariable("Measurement", "DIO13"));
            //list.Add(new Vector.CANoe.Runtime.DynamicSystemVariable("Measurement", "DIO14"));
            //list.Add(new Vector.CANoe.Runtime.DynamicSystemVariable("Measurement", "DIO15"));
            //list.Add(new Vector.CANoe.Runtime.DynamicSystemVariable("Measurement", "DIO16"));
            //list.Add(new Vector.CANoe.Runtime.DynamicSystemVariable("Measurement", "DIO17"));
            //list.Add(new Vector.CANoe.Runtime.DynamicSystemVariable("Measurement", "DIO18"));
            //list.Add(new Vector.CANoe.Runtime.DynamicSystemVariable("Measurement", "DIO19"));
            //list.Add(new Vector.CANoe.Runtime.DynamicSystemVariable("Measurement", "DIO20"));

            //list.Add(new Vector.CANoe.Runtime.DynamicSystemVariable("Measurement", "DIO21"));
            //list.Add(new Vector.CANoe.Runtime.DynamicSystemVariable("Measurement", "DIO22"));
            //list.Add(new Vector.CANoe.Runtime.DynamicSystemVariable("Measurement", "DIO23"));
            //list.Add(new Vector.CANoe.Runtime.DynamicSystemVariable("Measurement", "DIO24"));
            //list.Add(new Vector.CANoe.Runtime.DynamicSystemVariable("Measurement", "DIO25"));
            //list.Add(new Vector.CANoe.Runtime.DynamicSystemVariable("Measurement", "DIO26"));
            //list.Add(new Vector.CANoe.Runtime.DynamicSystemVariable("Measurement", "DIO27"));
            //list.Add(new Vector.CANoe.Runtime.DynamicSystemVariable("Measurement", "DIO28"));
            //list.Add(new Vector.CANoe.Runtime.DynamicSystemVariable("Measurement", "DIO29"));
            //list.Add(new Vector.CANoe.Runtime.DynamicSystemVariable("Measurement", "DIO30"));

            //list.Add(new Vector.CANoe.Runtime.DynamicSystemVariable("Measurement", "DIO31"));
            //list.Add(new Vector.CANoe.Runtime.DynamicSystemVariable("Measurement", "DIO32"));
            //list.Add(new Vector.CANoe.Runtime.DynamicSystemVariable("Measurement", "DIO33"));
            //list.Add(new Vector.CANoe.Runtime.DynamicSystemVariable("Measurement", "DIO34"));
            //list.Add(new Vector.CANoe.Runtime.DynamicSystemVariable("Measurement", "DIO35"));
            //list.Add(new Vector.CANoe.Runtime.DynamicSystemVariable("Measurement", "DIO36"));
            //list.Add(new Vector.CANoe.Runtime.DynamicSystemVariable("Measurement", "DIO37"));
            //list.Add(new Vector.CANoe.Runtime.DynamicSystemVariable("Measurement", "DIO38"));
            //list.Add(new Vector.CANoe.Runtime.DynamicSystemVariable("Measurement", "DIO39"));
            //list.Add(new Vector.CANoe.Runtime.DynamicSystemVariable("Measurement", "DIO40"));

            //list.Add(new Vector.CANoe.Runtime.DynamicSystemVariable("Measurement", "DIO41"));
            //list.Add(new Vector.CANoe.Runtime.DynamicSystemVariable("Measurement", "DIO42"));
            //list.Add(new Vector.CANoe.Runtime.DynamicSystemVariable("Measurement", "DIO43"));
            //list.Add(new Vector.CANoe.Runtime.DynamicSystemVariable("Measurement", "DIO44"));
            //list.Add(new Vector.CANoe.Runtime.DynamicSystemVariable("Measurement", "DIO45"));
            //list.Add(new Vector.CANoe.Runtime.DynamicSystemVariable("Measurement", "DIO46"));
            //list.Add(new Vector.CANoe.Runtime.DynamicSystemVariable("Measurement", "DIO47"));
            //list.Add(new Vector.CANoe.Runtime.DynamicSystemVariable("Measurement", "DIO48"));
            //list.Add(new Vector.CANoe.Runtime.DynamicSystemVariable("Measurement", "DIO49"));
            //list.Add(new Vector.CANoe.Runtime.DynamicSystemVariable("Measurement", "DIO50"));

            //list.Add(new Vector.CANoe.Runtime.DynamicSystemVariable("Measurement", "DI51"));
            //list.Add(new Vector.CANoe.Runtime.DynamicSystemVariable("Measurement", "DI52"));
            //list.Add(new Vector.CANoe.Runtime.DynamicSystemVariable("Measurement", "DI53"));
            //list.Add(new Vector.CANoe.Runtime.DynamicSystemVariable("Measurement", "DI54"));
            //list.Add(new Vector.CANoe.Runtime.DynamicSystemVariable("Measurement", "AIO1"));
            //list.Add(new Vector.CANoe.Runtime.DynamicSystemVariable("Measurement", "AIO2"));
            //list.Add(new Vector.CANoe.Runtime.DynamicSystemVariable("Measurement", "AIO3"));
            //list.Add(new Vector.CANoe.Runtime.DynamicSystemVariable("Measurement", "AIO4"));
            //list.Add(new Vector.CANoe.Runtime.DynamicSystemVariable("Measurement", "AIO5"));
            //list.Add(new Vector.CANoe.Runtime.DynamicSystemVariable("Measurement", "AIO6"));

            //list.Add(new Vector.CANoe.Runtime.DynamicSystemVariable("Measurement", "AIO7"));
            //list.Add(new Vector.CANoe.Runtime.DynamicSystemVariable("Measurement", "AIO8"));
            //list.Add(new Vector.CANoe.Runtime.DynamicSystemVariable("Measurement", "AIO9"));
            //list.Add(new Vector.CANoe.Runtime.DynamicSystemVariable("Measurement", "AIO10"));
            //list.Add(new Vector.CANoe.Runtime.DynamicSystemVariable("Measurement", "AIO11"));
            //list.Add(new Vector.CANoe.Runtime.DynamicSystemVariable("Measurement", "AIO12"));
            //list.Add(new Vector.CANoe.Runtime.DynamicSystemVariable("Measurement", "AIO13"));
            //list.Add(new Vector.CANoe.Runtime.DynamicSystemVariable("Measurement", "AIO14"));
            //list.Add(new Vector.CANoe.Runtime.DynamicSystemVariable("Measurement", "AIO15"));
            //list.Add(new Vector.CANoe.Runtime.DynamicSystemVariable("Measurement", "AIO16"));
        }
    }

}
