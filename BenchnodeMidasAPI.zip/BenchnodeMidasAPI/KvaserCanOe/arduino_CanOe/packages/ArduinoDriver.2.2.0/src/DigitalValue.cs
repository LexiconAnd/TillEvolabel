﻿namespace ArduinoDriver
{
    public enum DigitalValue
    {
        Low = 0,
        High = 1
    }
}
