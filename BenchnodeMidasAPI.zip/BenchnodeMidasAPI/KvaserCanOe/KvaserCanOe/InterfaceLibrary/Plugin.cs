﻿using System.Reflection;

namespace AutoTestNow
{
    public class PluginClass
    {
        public string Name;
        public string Type;
        public Assembly Plugin;
    }
}