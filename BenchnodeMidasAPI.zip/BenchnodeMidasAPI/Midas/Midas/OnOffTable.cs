﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace MidasAPI
{
    [Serializable]
    class OnOffRelayConfig
    {
        public String Name;
        public List<short>Relays = new List<short>();
      

    }
}
