﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;
using Kvaser.Kvadblib;
using AutoTestNow.Interfaces;

namespace AutoTestNow.Classes.DatabaseReaders
{       
   public class CanDBC:IDatabase
    {
        public Kvadblib.Hnd dbHandle;
        public Kvadblib.Status status;
        public Dictionary<string, List<string>> ECUListTx = new Dictionary<string, List<string>>(); // <ECUName,List<MessageName>> // TX Message
        public Dictionary<string, List<string>> ECUListRx = new Dictionary<string, List<string>>(); // <ECUName,List<MessageName>> // RX Message
        public Dictionary<int, string> MessageIdToMassageName = new Dictionary<int, string>(); // <MessageName, MessageID> koverterar mellan frameId och FrameName
        public Dictionary<string, MessageData> messageData = new Dictionary<string, MessageData>(); // <MessageName,MessageData> håller alla frame data. 
        public Dictionary<string, List<string>> messageList = new Dictionary<string, List<string>>(); //<MessageNamne,List<SignalNames>> håller namnet på alla signaler i en frame
        public Dictionary<string, SignalData> signalData = new Dictionary<string, SignalData>(); // <SignalName,SignalData>håller all data om en signal.

        public CanDBC(string dbPath)
        {
            if (dbPath == "")
            {
                return;
            }

            Kvadblib.Hnd hnd = new Kvadblib.Hnd();

            Kvadblib.Open(out hnd);

            status = Kvadblib.ReadFile(hnd, dbPath);

            if (status == Kvadblib.Status.OK)
            {
                dbHandle = hnd;
            }
        }

        public void load()
        {            
            Kvadblib.MessageHnd mh;
            Kvadblib.NodeHnd nh;
            Kvadblib.Status attribStatus;
            Kvadblib.Status nodeStatus;
            Kvadblib.AttributeHnd ah = new Kvadblib.AttributeHnd();

            String Name;
            Kvadblib.MESSAGE flags;

            status = Kvadblib.GetFirstMsg(dbHandle, out mh);
            while (status == Kvadblib.Status.OK)
            {
                MessageData mess = new MessageData();                 
                
                status = Kvadblib.GetMsgName(mh, out mess.Name);
                status = Kvadblib.GetMsgId(mh, out mess.Id, out flags);
                status = Kvadblib.GetMsgComment(mh, out mess.Comment);
                status = Kvadblib.GetMsgDlc(mh, out mess.dlc);
                status = Kvadblib.GetMsgQualifiedName(mh, out mess.QName);
                attribStatus = Kvadblib.GetFirstMsgAttribute(mh, ref ah);
                while ( attribStatus == Kvadblib.Status.OK)
                {
                    Kvadblib.GetAttributeName(ah, out Name);
                    mess.AttributeName.Add(Name);
                    attribStatus = Kvadblib.GetNextAttribute(ah, ref ah);
                }

                if (!messageData.Keys.Contains(mess.Name))
                {
                    messageData[mess.Name] = mess; // lägger till signal i lista 
                }
                MessageIdToMassageName[mess.Id] = mess.Name; // Kopplar Id till Namn.
               
                status = Kvadblib.GetNextMsg(dbHandle, out mh);
            }
            
            foreach (MessageData MD in messageData.Values)
            {
                status = Kvadblib.GetMsgById(dbHandle, MD.Id, out mh);
                nodeStatus = Kvadblib.GetMsgSendNode(mh, out nh);               
                while(nodeStatus == Kvadblib.Status.OK)
                {
                    Kvadblib.GetNodeName(nh, out Name);
                    if (!ECUListTx.Keys.Contains(Name)) // Not initated
                    {
                        ECUListTx[Name] = new List<string>();
                    }
                    if (!ECUListTx[Name].Contains(MD.Name)) // kollar om medelandet finns i listand redan
                    {
                        ECUListTx[Name].Add(MD.Name);
                    }
                    nodeStatus = Kvadblib.GetNextNode(dbHandle, out nh);
                }                
            }                   

            foreach (MessageData MD in messageData.Values)
            {
                LoadSignalsInFrame(MD.Id);
            }

            foreach( SignalData signal in signalData.Values)
            {
                foreach(string node in signal.RxECUs)
                {
                    if(!ECUListRx.Keys.Contains(node))
                    {
                        ECUListRx[node] = new List<string>();
                    }
                    if (!ECUListRx[node].Contains(signal.inMsg))
                    {
                        ECUListRx[node].Add(signal.inMsg);
                    }
                }
            }
        }

        private void LoadSignalsInFrame(int id)
        {
            //<MessafeNamne,List<SignalNames>>  messageList
            Kvadblib.MessageHnd msgHandle;
            Kvadblib.SignalHnd sh;
            Kvadblib.NodeHnd nh = new Kvadblib.NodeHnd();
            string msgName;            
            
                      
            Kvadblib.Status status = Kvadblib.GetMsgById(dbHandle, id, out msgHandle);
                        
            if(Kvadblib.GetMsgName(msgHandle, out msgName) != Kvadblib.Status.OK)
            {
                return; // if no frameName Exist then this wan't work
            }        

            status = Kvadblib.GetFirstSignal(msgHandle, out sh);

            while (status == Kvadblib.Status.OK)
            {               
                SignalData sig = new SignalData();
                sig.inMsg = msgName;
                // --- debiug 
                Kvadblib.SignalType type;
                Kvadblib.SignalType type2;                                 
                //----
                status = Kvadblib.GetSignalName(sh, out sig.Name);
                status = Kvadblib.GetSignalUnit(sh, out sig.unit);
                status = Kvadblib.GetSignalValueLimits(sh, out sig.min, out sig.max);
                status = Kvadblib.GetSignalValueScaling(sh, out sig.scale, out sig.offset);
                status = Kvadblib.GetSignalComment(sh, out sig.Comment);
                //status = Kvadblib.GetSignalEncoding(sh, out sig.Encoding);
                status = Kvadblib.GetSignalPresentationType(sh, out type);
                status = Kvadblib.GetSignalQualifiedName(sh, out sig.QName);
                status = Kvadblib.GetSignalRepresentationType(sh, out type2);
                //status = Kvadblib.GetSignalValueEnum(sh, out enumName, enums, dlc);
                status = Kvadblib.GetSignalValueSize(sh, out sig.startBit, out sig.length);
               
                foreach (string nodeName in ECUListTx.Keys)
                {
                    Kvadblib.GetNodeByName(dbHandle, nodeName, out nh);
                    if ( Kvadblib.SignalContainsReceiveNode(sh, nh) == Kvadblib.Status.OK)
                    {
                        sig.RxECUs.Add(nodeName);
                    }

                }                    
      

                if ( !signalData.Keys.Contains(sig.Name))
                {
                    signalData[sig.Name] = sig;
                }
                if (! messageList.Keys.Contains(msgName))
                {
                    messageList[msgName] = new List<string>();
                }
                if ( !messageList[msgName].Contains(sig.Name))
                {
                    messageList[msgName].Add( sig.Name );
                }

                

                status = Kvadblib.GetNextSignal(msgHandle, out sh);
            }                  

        }

        public List<int> GetRxECUFrameIds(string EcuName)
        {
            
            List<int> frameIds = new List<int>();
            foreach (string ECU in ECUListRx[EcuName])
            {
                frameIds.Add(messageData[ECU].Id);
            }

            return frameIds;
        }

        public List<int> GetTxECUFrameIds(string EcuName)
        {

            List<int> frameIds = new List<int>();
            foreach (string ECU in ECUListTx[EcuName])
            {
                frameIds.Add(messageData[ECU].Id);
            }

            return frameIds;
        }

        public Dictionary<string, string> GetSignalsInfram(CanMessage frame)
        {
            Dictionary<string, string> signalList = new Dictionary<string, string>();
            foreach (string sigName in messageList[MessageIdToMassageName[frame.id]])
            {
                string value = "";
                SignalData sig = signalData[sigName];
                for (int i = sig.startBit; i < sig.startBit + sig.length; i++)
                {
                    value += frame.data[i];
                }
            }

            return signalList;
        }

        public Dictionary<string, SignalData> GetAllSignalsInDB()
        {
            return signalData;
        }

        public double GetSignalValue(string signalName, CanMessage frame)
        {
            //if (signalData.ContainsKey(signalName))
            //{
            //    SignalData signal = signalData[signalName];
            //    signal.startBit
            //}
            return 0;
        }

        public double GetSignalValue(string signalName)
        {
            throw new NotImplementedException();
        }
    }

    
}
