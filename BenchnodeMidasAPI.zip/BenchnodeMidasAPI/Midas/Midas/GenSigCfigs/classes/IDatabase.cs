﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace AutoTestNow.Interfaces
{
    public class SignalData
    {
        public string Name;
        public string QName;
        public string unit;
        public double min;
        public double max;
        public double scale;
        public double offset;
        public string Comment;

        public int startBit;
        public int length;
        public List<String> RxECUs = new List<string>();
        public string inMsg = "";
        //public Kvadblib.SignalEncoding Encoding;
    }

    public class MessageData
    {
        public string Name;
        public int Id;
        //public Kvadblib.MESSAGE flags;
        public string Comment;
        public int dlc;
        public string QName;
        public List<string> AttributeName = new List<string>();
    }

    public interface IDatabase
    {
        List<int> GetRxECUFrameIds(string EcuName );
        List<int> GetTxECUFrameIds(string EcuName);
        Dictionary<string,string> GetSignalsInfram(CanMessage frame); // returns a key par with signalname and value
        double GetSignalValue(string signalName);
    }

}
