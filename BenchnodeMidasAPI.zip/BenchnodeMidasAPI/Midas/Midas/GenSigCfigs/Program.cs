﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using AutoTestNow.Classes.DatabaseReaders;
using AutoTestNow.Interfaces;

namespace GenSigCfigs
{
    class Program
    {
        static void Main(string[] args)
        {
            CanDBC db = new CanDBC(@"H:\SYSTEM\My Documents\CANoe\RelayConfig.dbc");
            db.load();
            foreach(SignalData sig in db.GetAllSignalsInDB().Values)
            {
                Console.WriteLine(sig.Name); 
            }
           
        }
    }
}
