﻿using System;
using Vector.Tools;
using Vector.CANoe.Runtime;
using Vector.CANoe.Sockets;
using NetworkDB;
using Vector.Diagnostics;
using Diag = Vector.Diagnostics;


namespace MidasAPI
{
    public partial class Midas : MeasurementScript
    {
        [OnChange(typeof(AVAS))]
        public void on_sig_AVAS()
        {
            rc.IPC(AVAS.Value, "AVAS", Relay_Calculator.SignalType.onoff);


        }

        [OnAnyCANFrame]
        public void onMessage1(NetworkDB.Frames.AVAS01 frame)           
        {
            
            rc.IPC(frame.AVAS.Value, "AVAS",Relay_Calculator.SignalType.onoff); 
            rc.IPC(frame.AVAS_BAT.Value, "AVAS_BAT",Relay_Calculator.SignalType.status);
            rc.IPC(frame.AVAS_CAN_L.Value, "AVAS_CAN_L", Relay_Calculator.SignalType.status);
            rc.IPC(frame.AVAS_GND.Value, "AVAS_GND", Relay_Calculator.SignalType.status);
        }
       

    }
}