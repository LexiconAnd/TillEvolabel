﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Globalization;
using System.IO.Ports;
using DamienG.Security.Cryptography;
using System.Threading;
using System.Text;
using Vector.Tools;

namespace MidasAPI
{

    public class MidasApi
    {
        private SerialPort port; //= new SerialPort("COM3", 115200, Parity.None, 8, StopBits.One);
        private int MAX_PIN_NUMBERS = 32;

        public MidasApi()
        {           
        }

        /// <summary>
        /// Since the diagnostic message is always the same, its crc is precalculated and
        /// returned together with the preamble 48 (0x30) which is the code for sending a
        /// diagnostic message to Arduino
        /// </summary>
        /// <returns> an int array of the preamble and its crc </returns>


        public string diagnostic()

        {
            return  Send(new byte[] { 0x30 }); 
        }

        /// <summary>
        /// Since the clear all registers message is always the same, its crc is precalculated and
        /// returned together with the preamble 80(0x50) which is the code for commanding Arduino to
        /// clear all shift registers
        /// </summary>
        /// <returns> an int array of the preamble and its crc </returns>
        /// 
        public string clearAll()
        {
            return Send(new byte[] { 80 });


                         // return new byte[] { 0x50, 80, 185, 105, 190, 121 };
           // return Encoding.ASCII.GetBytes(response);
        }

        /// <summary>
        /// The ping messsage sent to Arduino remanis the same, so its crc is precalculated and
        /// returned together with the preamble 112(0x70) which is the code for pinging Arduino
        /// </summary>
        /// <returns> an int array of the preamble and its src </returns>


        public string pingArduino() //public byte[] 
        {

            return Send(new byte[] { 112 }); // string response = Send

            // return Encoding.ASCII.GetBytes(response);

            // return new byte[] { 0X70, 112, 130, 7, 158, 177 };

        }

        // Moving a byte 8 steps to left and sends it as a message


        public string initNumberOfRegisters(short nrOfRegisters) //  public byte[]
        {
            if (nrOfRegisters > short.MaxValue || nrOfRegisters < 1)
            {
                throw new ArgumentException("Number of registers can't be higher than 32677 inclusive or lower than 1"); // error message
            }

            else

            {

                byte preamble = 0x60;

                byte firstByte = byte.Parse(((nrOfRegisters & 0xFF00) >> 8).ToString()); // var 8
                byte Seconbyte = byte.Parse(((nrOfRegisters & 0x00FF).ToString()));
                byte[] message = new byte[] { preamble, firstByte, Seconbyte }; // byte[]
                string response = Send(message);
                return "message";  //Ändrat

            }
        }

        public byte[] setPin(short pinNumber, bool pinState)
        {            
            byte[] sendArray = new byte[4];
            if (pinNumber > 4080 || pinNumber < 1)
            {
                throw new ArgumentException("The pin can't be higher than 32677 inclusive or lower than 1");
            }            

            sendArray[0] = 0x40;
            sendArray[1] = (byte)((pinNumber & 0xFF00) << 8);
            sendArray[2] = (byte)((pinNumber & 0x00FF) << 8);
            sendArray[3] = (pinState==true)?(byte)1:(byte)0;       
            string respons = Send(sendArray);
            Console.WriteLine("Midas initiation message:" + sendArray);
            return sendArray;  

        }

        // list is bitcoded short nrOfRegisters. Calculating bytes and takes in a preambel to decide what message to be sent
        public bool setArray(Byte[] listOfValues)
        {
            if (listOfValues.Length > MAX_PIN_NUMBERS)
            {
                throw new System.ArgumentException("The listelements can't be a higher quantity of the number " + MAX_PIN_NUMBERS);
            }

            string respons = "";
            int nrOfFrames = (listOfValues.Count() / 255) + 1; //(listOfValues.Count() / 255) + 1;
            int lastFrameLefOwers = (listOfValues.Count() % 255);
            byte[] bytesToSend;

            for (int i = 0; i < nrOfFrames; i++)
            {

                bytesToSend = (nrOfFrames - 1 == i) ? new Byte[lastFrameLefOwers + 2] : new Byte[257];
                bytesToSend[0] = (nrOfFrames - 1 == i) ? (byte)0x20 : (byte)0x10;
                bytesToSend[1] = (nrOfFrames - 1 == i) ? (byte)lastFrameLefOwers : (byte)255;
                for (int d = 0; d < bytesToSend[1]; d++)
                {
                    bytesToSend[d + 2] = listOfValues[d + (i * 255)]; // bytesToSend[d + 2]
                }
                respons = Send(bytesToSend);
                Console.WriteLine("Midas test message:" + respons);
                if (respons != "16")

                {

                    break;
                }
            }
            if (respons == "16")
            {
                return true;
            }
            return false;

        }


        private string Send(byte[] data)
        {    

            Crc32 crc32 = new Crc32();
            byte[] sendData = new byte[data.Count() + 4]; //was + 4
            int count = 0;


            foreach (byte item in data)
            {
                sendData[count++] = item;
            }

            foreach (byte b in crc32.ComputeHash(data))
            {
                sendData[count++] = b;
            }
            return sendRS232(sendData);

        }

        protected virtual string sendRS232(byte [] data)
        {
            string respons = "";
            if ( port == null)
            {
                port = new SerialPort("COM3", 115200, Parity.None, 8, StopBits.One);
            }
            try
            {
                if (!port.IsOpen)
                {
                    port.Open();
                    port.DtrEnable = true;

                    byte midasInitiateByte;
                    while (port.BytesToRead < 1) ;
                    while (port.BytesToRead > 0)
                    {
                        midasInitiateByte = (byte)(port.ReadByte() & 0xff);
                        // skall tas bort Output.WriteLine("Midas initiation message:" + midasInitiateByte); 

                    }
                }
            }
            catch (Exception)
            {
                respons = "it went to hell";
                return respons;
            }

            port.Write(data, 0, data.Length);

           byte portByte;  // Har kommenterats bort pga canoe kan behövas u framtiden
            while (port.BytesToRead < 1);
            while (port.BytesToRead > 0)
            {
                portByte = (byte)(port.ReadByte() & 0xff);
                respons += port.ReadByte();
            }
            return respons;
        }
    }
}





