﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Vector.Tools;
using System.Xml;
using System.Xml.Serialization;
using System.IO;
using Vector.Tools;

namespace MidasAPI
{

    public partial class Relay_Calculator
    {
        private static MidasApi Midas_h = new MidasApi();

        //  public IPCsignals Gnd = new IPCsignals();
        public enum Status { Connected = 0, NC = 1, BAT = 2, GND = 3 };
        public enum OnOff { Connected = 0, Disabel = 1 }
        public enum SignalType { onoff, status }
        public List<RealyTable> RelayConfig = new List<RealyTable>();
        public List<OnOff> OnOffStatus = new List<OnOff>();



        //private static List<SignalInfo> sigValues = new List<SignalInfo>();
        private short x = 1;



        public void RelayConfiguration()
        {
            XmlSerializer list = new XmlSerializer(typeof(List<RealyTable>));
            foreach (string file in Directory.GetFiles(@"\\sethnna002-48\userhome\USERHOME30$\KZ8383\SYSTEM\My Documents\CANoe\Midas\relayConfigs", "*.xml"))
            {
                using (XmlReader xmlfile = XmlReader.Create(file))
                {
                    RelayConfig.AddRange((List<RealyTable>)list.Deserialize(xmlfile));
                }

            }
        }

        public void OnOffConfiguration()
        {
            //XmlSerializer list = new XmlSerializer(typeof(List<OnOff>));
            //foreach (string file in Directory.GetFiles(@"\\sethnna002-48\userhome\USERHOME30$\KZ8383\SYSTEM\My Documents\CANoe\Midas\relayConfigs", "*.xml"))
            //{
            //    using (XmlReader xmlfile = XmlReader.Create(file))
            //    {
            //        OnOffStatus.AddRange((List<OnOff>)list.Deserialize(xmlfile));
            //    }

            //}
        }



        public void IPC(double sigValue, string name, SignalType type)
        {
          //  SignalInfo sig = sigValues.FirstOrDefault(x => x.name == name);
            //if (sig == null)
            //{
            //   // SignalInfo info = new SignalInfo();
            // //   info.name = name;
            //   // info.currentValue = sigValue;
            // //   sigValues.Add(info);
            //  //  sig = sigValues.FirstOrDefault(x => x.name == name);
            //}

            //if (sig.currentValue != sigValue)  // har ändrats
            //{
            //    sig.currentValue = sigValue;
             //   Output.WriteLine(sig.name + "=" + sig.currentValue);
                Output.WriteLine(RelayConfig.First(x => x.Name == name).NC.ToString());
                PinControle((Status)sigValue, RelayConfig.First(x => x.Name == name));
        //    }

        }


        public void PinControle(Status pinStatus, RealyTable pinNumber)
        {
            switch (pinStatus)
            {
                case Status.Connected:
                    Midas_h.setPin(pinNumber.NC, false);
                    break;
                case Status.NC:
                    Midas_h.setPin(pinNumber.NC, true);
                    break;
                case Status.GND:
                    break;
                case Status.BAT:
                    break;
            }
        }



        private void setPin(OnOff OnOFF, OnOffRelayConfig Config )
        {
            bool pinstate = (OnOFF == OnOff.Connected)?false:true;
           
            foreach(short pin in Config.Relays)
            {
                Midas_h.setPin(pin, pinstate);
            }
        }
    }
} 

    
        





       
    

 
    


