﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace MidasAPI
{

    
    public class Signal
    {
        public string LocalSig{ get; }

        public Signal(string localSig)
        {
            LocalSig = localSig;
        }

        public override string ToString()
        {
            return LocalSig;
        }
    }

    public abstract class Controller
    {
        public Signal RootAction => new Signal(GetSig());

        protected abstract string Root { get; }

        public Signal BuildAction(string actionName)
        {
            var localSig = GetSig() + "/" + actionName;
            return new Signal(localSig);
        }

        private string GetSig()
        {
            if (Root == "")
            {
                return "";
            }

            return "/" + Root;
        }
        //controllers  example the SigController:
        public static readonly DataController Data = new DataController();
        public class DataController : Controller
        {
            public const string WN_right_upAction = "WN_right_up";
            public const string WN_left_downAction = "WN_left_down";
            public const string WN_left_upAction = "WN_left_up";
            public const string WN_right_downAction = "WN_right_down";
         

            protected override string Root => "data";

            public Signal WN_right_up => BuildAction(WN_right_upAction);
            public Signal WN_left_down => BuildAction(WN_left_downAction);
            public Signal WN_left_up => BuildAction(WN_right_downAction);
            public Signal WN_right_down => BuildAction(WN_right_downAction);
        }  
    }
    // GET: Data/WN_right_upAction
    [ActionName(ControllerRoutes.DataController.WN_right_upAction)]
    public ActionResult Etisys()
    {
        return View();
    }




    // CsHtmlkod
<ul>
    <li><a href = "@ControllerRoutes.Data.WN_right_up" > WN_right_up </ a ></ li >

    < li >< a href="@ControllerRoutes.Data.WN_left_down">WN_left_down</a></li>

        < li >< a href = "@ControllerRoutes.Data.WN_left_up" > WN_left_up </ a ></ li >

        < li >< a href="@ControllerRoutes.Data.WN_right_down">WN_right_down</a></li>
</ul>

}
