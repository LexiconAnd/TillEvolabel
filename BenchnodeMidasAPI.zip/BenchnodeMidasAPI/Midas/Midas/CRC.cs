﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CRCn

{
    public class CRC
    {
        private static readonly uint[] _crc32Table = new uint[256];
        private static readonly uint _ulPolynomial = 0x04c11db7;


        public static uint GenCRC32(string data)
        {
            InitCrcTable();

            uint crc = getCRC(Encoding.ASCII.GetBytes(data), Encoding.ASCII.GetBytes(data).Length);

            return crc;
        }

        private static void InitCrcTable()
        {

            // 256 values representing ASCII character codes.

            for (uint i = 0; i <= 0xFF; i++)
            {
                _crc32Table[i] = Reflect(i, 8) << 24;

                for (uint j = 0; j < 8; j++)
                {
                    long val = _crc32Table[i] & (1 << 31);

                    if (val != 0)
                        val = _ulPolynomial;
                    else val = 0;

                    _crc32Table[i] = (_crc32Table[i] << 1) ^ (uint)val;
                }

                _crc32Table[i] = Reflect(_crc32Table[i], 32);
            }



        }

        private static uint Reflect(uint re, byte ch)
        {  // Used only by Init_CRC32_Table()

            uint value = 0;

            // Swap bit 0 for bit 7
            // bit 1 for bit 6, etc.
            for (int i = 1; i < (ch + 1); i++)
            {
                long tmp = re & 1;
                int v = ch - i;

                if (tmp != 0)
                    value |= (uint)1 << v; //(uint)(ch - i));

                re >>= 1;
            }

            return value;
        }

        private static uint getCRC(byte[] buffer, int bufsize)
        {

            uint crc = 0xffffffff;
            int len = bufsize;
            // Save the text in the buffer.

            // Perform the algorithm on each character
            // in the string, using the lookup table values.

            for (uint i = 0; i < len; i++)
                crc = (crc >> 8) ^ _crc32Table[(crc & 0xFF) ^ buffer[i]];


            // Exclusive OR the result with the beginning value.
            return crc ^ 0xffffffff;

        }


    }

}
