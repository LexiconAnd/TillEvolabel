﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AutoTestNow
{
    public class CanMessage
    {
        public string alias;
        public enum state { normal, canClose, canBusOff, canBusOn, canIoCtl, canSetBusParams, canOpenChannel, failedToSend }
        public int id;
        public byte[] data = new byte[8] { 0, 0, 0, 0, 0, 0, 0, 0 };
        public int dlc;
        public int flags;
        public long time;
        public bool extended;
        public bool rx;
        public bool IsErrorFrame = false;
        public bool IsStatus = false;
        public string sFlags = "";
        public state status;
        public int Channel;



        public CanMessage(bool Error, String Flags)
        {
            IsErrorFrame = Error;
            sFlags = Flags;
        }

        public CanMessage(int id, byte[] data, int dlc, int flags, long time, string sFlags, int channel)
        {
            this.id = id;
            this.data = data;
            this.dlc = dlc;
            this.flags = flags;
            this.time = time;
            this.sFlags = sFlags;
            this.Channel = channel;
        }

        public CanMessage(int id, Byte[] data, int dlc, int flags)
        {
            this.id = id;
            this.data = data;
            this.dlc = dlc;
            this.flags = flags;
        }

        public CanMessage(state msgStatus, long statusTime)
        {
            this.status = msgStatus;
            this.time = statusTime;
            IsStatus = true;
        }

        public CanMessage()
        {

        }

        public override string ToString()
        {
            string sdata = "";
            if (IsErrorFrame)
            {
                if (status == state.failedToSend)
                {
                    for (int i = 0; i < dlc; i++)
                    {
                        sdata += data[i].ToString("X") + ",";
                    }
                    sdata = sdata.TrimEnd(',');
                    return "*ERROR failed to send on Channel:" + Channel + "*, Time:" + time + " Id:" + id + " Dlc:" + dlc + " [" + sdata + "] Flag:" + sFlags;
                }
                return "***ERROR FRAME RECEIVED on Channel: " + Channel + "***," + time + "," + sFlags;
            }
            if (IsStatus)
            {
                return "***Error on Status " + status.ToString() + "  on Channel:" + Channel + "***," + DateTime.FromFileTime(time);
            }

            if (dlc > 8)
            {
                dlc = 8;
            }
            for (int i = 0; i < dlc; i++)
            {
                sdata += data[i].ToString("X2") + ",";
            }
            sdata = sdata.TrimEnd(',');
            return "Time:" + time + " Id:" + id.ToString("x") + " Channel:" + Channel + " Dlc:" + dlc + " [" + sdata + "] Flag:" + sFlags;
        }

        private String state2String(state input)
        {
            switch (input)
            {
                case state.canBusOff:
                    return "CanBusOff";
                case state.canBusOn:
                    return "CanBusOff";
                case state.canClose:
                    return "CanBusOff";
                case state.canIoCtl:
                    return "CanBusOff";
                case state.canOpenChannel:
                    return "CanBusOff";
                case state.canSetBusParams:
                    return "CanBusOff";
            }
            return ((int)input).ToString();
        }
    }
}
