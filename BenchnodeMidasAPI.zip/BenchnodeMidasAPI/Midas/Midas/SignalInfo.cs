﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace MidasAPI

{
    public class SignalInfo
    {
        public string name;
        public double currentValue;
    }
    
}
