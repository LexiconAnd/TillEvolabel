using System;
using Vector.Tools;
using Vector.CANoe.Runtime;
using Vector.CANoe.Sockets;
using NetworkDB;
using Vector.Diagnostics;
using Diag = Vector.Diagnostics;


namespace MidasAPI//ny 
{
    public partial class Midas : MeasurementScript
    {
        private Relay_Calculator rc = new Relay_Calculator();
       

       
      

        public override void Initialize()
        {
            rc.RelayConfiguration();
        }

        public override void Start()
        {
            Output.WriteLine("test CAN");
            //MidasApi serial = new MidasApi();
            //AVAOutput.WriteLine(serial.read());
        }

        public override void Stop()
        {

        }

        public override void Shutdown()
        {

        }

   }

} 

