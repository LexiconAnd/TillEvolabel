﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace MidasAPI
{
    [Serializable]
    public class RealyTable
    {
        public String Name;
        public short NC;
        public short BAT;
        public short GND;

        public RealyTable()
        {

        }

        public RealyTable(string name, short nc)
        {
            Name = name;
            NC = nc;
        }

        public RealyTable(string name, short nc, short bat, short gnd)
        {
            Name = name;
            NC = nc;
            BAT = bat;
            GND = gnd;
        }
    }
}
