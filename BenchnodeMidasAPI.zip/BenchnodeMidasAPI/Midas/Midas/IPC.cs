﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace MidasAPI
{
    public partial class Relay_Calculator
    {
        void Def()
        {
            RelayConfig.Add(new RealyTable("AVAS", 0));
            RelayConfig.Add(new RealyTable("AVAS_BAT", 1));
            RelayConfig.Add(new RealyTable("AVAS_CAN_L", 2));
            RelayConfig.Add(new RealyTable("AVAS_GND", 3));
         
        }

    }
}
