﻿using System;
using System.Collections.Generic;
using System.Linq;

namespace VehicleGarage
{
    public class Vehicle
    {
        public string licensePlate;
        public int size;
        public Vehicle(string lPlate)
        {
            licensePlate = lPlate;
            size = 2; // or used yet
        }
    }
    public class Garage
    {
        private int MAX=5;  // MAX=100;
        public ParkingSpace[] parkingSlot;
        public Garage()
        {
            parkingSlot = new ParkingSpace[MAX];
            for (int i=0; i<parkingSlot.Count(); i++)
            {
                parkingSlot[i] = new ParkingSpace();
            }
        }
        public void AddVehicle(string licPlate)
        {
            bool added = false;
            for (int i=0; i < parkingSlot.Count(); i++)
            {
                added = parkingSlot[i].AddVehicle(licPlate);
                if (added) break;
            }
        }
        public void RemoveVehicle(string licPlate)
        {
            bool removed = false; 
            for (int i=0; i<parkingSlot.Count(); i++)
            {
                removed = parkingSlot[i].RemoveVehicle(licPlate);
                if (removed) break; 
            }
        }
        public bool FindVehicle(string licPlate)
        {
            bool found = false;
            for (int i=0; i<parkingSlot.Count(); i++)
            {
                found = parkingSlot[i].FindVehicle(licPlate);
                if (found) break;
            }
            return found;
        }
        public void PrintInfo()
        {
            Console.WriteLine("-------Garage Info --------");

            for (int i=0; i < parkingSlot.Count(); i++)
            {
                Console.Write(i + ":");
                Console.Write(parkingSlot[i].Info());
                Console.WriteLine();
            }
            Console.WriteLine("-------Garage End  --------");

        }
    }
    public class ParkingSpace
    {
        public List<Vehicle> list;
        public ParkingSpace()
        {
            list = new List<Vehicle>();
        }
        public bool AddVehicle(string licPlate)
        {
            bool added = false;
            // let assume that max 2 vehicles per slot
            if (list.Count() < 2)
            {
                list.Add(new Vehicle(licPlate));
                added = true;
            }
            return added;
        }
        public bool RemoveVehicle(string licPlate)
        {
            bool removed = false;
            for (int i=0; i<list.Count(); i++)
            {
                if (list.ElementAt(i).licensePlate==licPlate)
                {
                    list.RemoveAt(i);
                    removed = true;
                    break;
                }
            }
            return removed;
        }
        public bool FindVehicle(string licPlate)
        {
            bool found = false;
            for (int i=0; i< list.Count(); i++)
            {
                if (list.ElementAt(i).licensePlate ==licPlate)
                {
                    found = true;
                    break;
                }
            }
            return found;
        }
        public string Info()
        {
            string infoStr = " ";
            for (int i = 0; i < list.Count(); i++)
            {
                infoStr = infoStr + list.ElementAt(i).licensePlate + "  ";
            }
            return infoStr;
        }

    }

    class Program
    {
        static void Main(string[] args)
        {
            Garage g = new Garage();

            // Main menu loop
            bool    ready = false, found;
            string  licensePlateStr;

            while (!ready)
            {
                Console.Write("a-add, r-remove, f-find, q-quit: ");
                string answer = Console.ReadLine();
                switch (answer)
                {
                    case "q":
                        ready = true;
                        break;
                    case "a":
                        Console.Write("Lic Plate:");
                        licensePlateStr = Console.ReadLine();
                        g.AddVehicle(licensePlateStr); 
                        break;
                    case "r":
                        Console.Write("Lic Plate:");
                        licensePlateStr = Console.ReadLine();
                        g.RemoveVehicle(licensePlateStr);
                        break;
                    case "f":
                        Console.Write("Lic Plate:");
                        licensePlateStr = Console.ReadLine();
                        found = g.FindVehicle(licensePlateStr);
                        if (found)
                             Console.WriteLine(licensePlateStr + " found!");
                        else Console.WriteLine(licensePlateStr + " NOT found!");
                        break;
                    default:
                        break;
                }
                g.PrintInfo();
                 
            }
        }
    }
}

